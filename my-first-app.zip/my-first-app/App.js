import React, { Component } from 'react';
import { Button, View, Text, Alert} from 'react-native';

class Losbotones extends Component {
  render(){
    return(
      <Button title={this.props.title} color={this.props.color} onPress={() => Alert.alert(this.props.title + this.props.id)}></Button>
    )
  }
}

export default class App extends Component {
  render() {
    return (
       
       <View style={{width:200, marginTop:300, marginLeft:80}}>
        <Losbotones title="Loki Friggason" color="#144d10" id="     edad:1053                  Dios de las mentiras"/>
        <Losbotones title="Tom Hiddleston" color="#d1ac17" id="     edad:40                    Actor Profecional"/>
        <Losbotones title="Jonathan Pine" color="#039c8c"  id="     edad:35                    Espia de el MI6"/>
        <Text style={{marginTop:100, marginLeft:45, color:"#4b0275", fontSize:50, fontFamily: 'monospace'}}>mi App</Text>
      </View>
    );
  }
}